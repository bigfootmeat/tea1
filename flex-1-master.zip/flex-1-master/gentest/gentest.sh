echo "This script is no longer needed!"
echo "================================"
echo "1. Simply open up gentest/test.html"
echo "2. It has some sample test data already loaded"
echo "3. Click the first button to load your custom html"
echo "4. Then copy the fixed/float test cases by clicking the second/third buttons"
echo "Note: gentest.js has a comment at the bottom with the entire test data in it."
echo "You can copy from that into the webpage. Make sure you add all new test cases to that comment in gentest.js"

